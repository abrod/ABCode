package de.brod.tools.cardmaniac;

import de.brod.gui2d.G2dContext;
import de.brod.gui2d.G2dView;

public class MainActivity extends G2dContext {

	@Override
	protected G2dView createView() {
		// TODO Auto-generated method stub
		return new CMView(this);
	}

}
