package de.brod.tools.cardmaniac;

import java.util.ArrayList;

import android.graphics.Bitmap;
import android.graphics.Rect;
import de.brod.gui2d.G2dButton;
import de.brod.gui2d.G2dContext;
import de.brod.gui2d.G2dImage;
import de.brod.gui2d.G2dView;
import de.brod.tools.cardmaniac.games.FreeCell;
import de.brod.tools.cardmaniac.games.Game;
import de.brod.tools.cardmaniac.gui.Card;
import de.brod.tools.cardmaniac.gui.Hand;
import de.brod.tools.cardmaniac.gui.Images;

public class CMView extends G2dView<Card> {

	private int iImgX;
	private int iImgY;
	// 	private G2dImage background;
	private ArrayList<Hand> lstHand;
	private Game game;
	private ArrayList<Card> lstAllItems;

	private ArrayList<Card> lstSelectedCards = new ArrayList<Card>();
	private G2dImage defaultImage;
	private G2dImage background;

	public CMView(G2dContext context) {
		super(context);
	}

	@Override
	protected void drawBackGround() {
		// clear(Color.BLACK);
		tile(background, 0, 0, width, height);
	}

	@Override
	protected Bitmap getIcon() {
		Bitmap icon = game.getIcon(titleBarHeight);
		if (icon == null) {
			if (defaultImage == null) {
				int x = titleBarHeight;
				defaultImage = G2dImage.get("default", x, x, getResources(),
						R.drawable.ic_launcher, 1, 1, 1);
			}
			icon = defaultImage.getBitmap();
		}
		return icon;
	}

	@Override
	protected String getTitle() {
		return game.getTitle();
	}

	@Override
	protected void initButtons(ArrayList<G2dButton> plstButtons) {
		super.initButtons(plstButtons);
		plstButtons.add(G2dButton.Types.UNDO.create());
		plstButtons.add(G2dButton.Types.REDO.create().setActive(false));
		plstButtons.add(G2dButton.Types.SETTINGS.create());
	}

	private void initGame() {
		lstHand.clear();

		game = new FreeCell();
		boolean bLandscape = width > height;
		Rect drawArea;
		if (bLandscape) {
			drawArea = new Rect(0, titleBarHeight, width, height);
		} else {
			drawArea = new Rect(0, titleBarHeight, width, height
					- titleBarHeight);
		}

		game.init(bLandscape, lstHand, Math.min(width, height), drawArea,
				getResources());

		// add the items from the hands
		lstAllItems.clear();
		for (Hand h : lstHand) {
			h.organize();
			lstAllItems.addAll(h.getAllCards());
		}

	}

	@Override
	protected void initView(ArrayList<Card> pLstItems) {

		int min = Math.min(width, height) / 5;
		// init the background
		background = G2dImage.get("bckgrnd", 5, height, 1, 1);
		Images.getBackgroundBitmap(background.getBitmap());
		// init the members
		lstAllItems = pLstItems;
		lstHand = new ArrayList<Hand>();

		// first init the game
		initGame();
	}

	@Override
	protected boolean mouseDown(Card rectItem) {
		Hand handTo = rectItem.getHand();
		lstSelectedCards.clear();
		Hand selectedHand = null;
		for (Hand h : lstHand) {
			for (Card c : h.getPlayingCards()) {
				if (c.isSelected()) {
					selectedHand = h;
					lstSelectedCards.add(c);
				}
			}
			if (selectedHand != null && selectedHand != handTo) {
				if (game.mouseUp(lstSelectedCards, handTo)) {
					for (Card c : handTo.getPlayingCards()) {
						c.setSelected(c.isMoving());
					}
				}
				selectedHand.organize();
				handTo.organize();
				return true;
			} else {
				for (Card c : lstSelectedCards) {
					c.setSelected(false);
				}
			}
		}

		boolean mouseDown = game.mouseDown(rectItem);
		// set the selected flag
		for (Card c : handTo.getPlayingCards()) {
			c.setSelected(c.isMoving());
		}
		return mouseDown;
	}

	@Override
	protected void mouseUp(ArrayList<Card> lstMove, Card moveTo) {
		if (moveTo != null) {
			Hand hand = moveTo.getHand();
			if (game.mouseUp(lstMove, hand)) {
				for (Card c : hand.getPlayingCards()) {
					c.setSelected(c.isMoving());
				}
			}
		}
		for (Hand h : lstHand) {
			h.organize();
		}
	}
}
