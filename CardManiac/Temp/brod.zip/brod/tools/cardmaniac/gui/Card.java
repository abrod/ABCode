package de.brod.tools.cardmaniac.gui;

import java.util.ArrayList;
import java.util.List;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import de.brod.gui2d.G2dColor;
import de.brod.gui2d.G2dImage;
import de.brod.gui2d.G2dItem;

public class Card extends G2dItem {

	private static int COLOR_SELECTED = Color.argb(255, 192, 192, 160);

	private static List<Card> lstCards = new ArrayList<Card>();
	static int cellWidth;
	static int cellHeight;
	private static G2dImage image;

	public static Card createCard(int x, int y, int piColor, int piValue) {
		Card c = new Card(x, y, cellWidth, cellHeight);
		c.setImage(image, piColor, piValue);
		lstCards.add(c);
		return c;
	}

	public static void init(int cntX, int w, Resources res) {
		G2dImage.clear("cards");

		COLOR_SELECTED = G2dColor.getDefaultColor().getColor(2.5f);
		//		image = G2dImage.get("cards", width, height, res, R.drawable.cards,
		//				cntX, 13, 5);
		w = w / 8;
		int h = w * 3 / 2;
		w *= 13;
		h *= 5;
		if (!G2dImage.contains("cards")) {
			image = G2dImage.get("cards", w, h, 13, 5);
			Images.getCardsBitmap(image.getBitmap(), w, h);
			image.consumeBitmap();
		} else {
			image = G2dImage.get("cards", w, h, 13, 5);
		}

		lstCards.clear();
		cellWidth = image.getCellWdith();
		cellHeight = image.getCellHeight();
	}

	private Paint borderPaint;

	private Hand hand;

	private RectF rectF;

	private Card(int px, int py, int piWidth, int piHeight) {
		super(px, py, piWidth, piHeight);
		borderPaint = new Paint();
		borderPaint.setStyle(Style.STROKE);
		borderPaint.setColor(G2dColor.getDefaultColor().getColor());
		borderPaint.setStrokeWidth(Images.rx);
	}

	@Override
	public void drawBorder(Canvas canvas) {
		canvas.drawRoundRect(rectF, Images.rx, Images.rx, borderPaint);
	}

	public int getColor() {
		return getCellY();
	}

	public Hand getHand() {
		return hand;
	}

	public int getValue() {
		return getCellX();
	}

	@Override
	public void moveTo(int px, int py) {
		super.moveTo(px, py);
		Rect r = getRect();
		if (rectF == null) {
			rectF = new RectF(r.left, r.top, r.right + 1, r.bottom + 1);
		} else {
			rectF.set(r.left, r.top, r.right + 1, r.bottom + 1);
		}
	}

	public void setHand(Hand hand) {
		this.hand = hand;
	}

	@Override
	public void setSelected(boolean pbSelected) {
		super.setSelected(pbSelected);
		if (pbSelected) {
			setColor(COLOR_SELECTED);
		} else {
			setColor(null);
		}
		hand.checkSelected();
	}
}
