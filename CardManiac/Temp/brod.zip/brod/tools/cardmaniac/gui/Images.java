package de.brod.tools.cardmaniac.gui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import de.brod.gui.DrawableBitmapContainer;
import de.brod.gui2d.G2dColor;

public class Images {

	// http://en.wikipedia.org/wiki/List_of_XML_and_HTML_character_entity_references
	private static String[] sColors = { String.valueOf((char) 9827),
			String.valueOf((char) 9824), String.valueOf((char) 9829),
			String.valueOf((char) 9830) };
	private static String[] sValues = { "A", "2", "3", "4", "5", "6", "7", "8",
			"9", "10", "B", "D", "K" };
	static float rx;

	private static void drawText(DrawableBitmapContainer c, int size, int x,
			int y, int h, String text, int piColor) {
		if (x > -5 && x - 5 < size && y > -5 && y - 5 < size) {
			c.drawText(x, y, h, text, piColor, Align.CENTER, Align.CENTER);
		}
	}

	//	public static void getBackgroundBitmap(Bitmap pBmp, int width, int height) {
	//		DrawableBitmapContainer c = new DrawableBitmapContainer(width, height);
	//
	//		// http://en.wikipedia.org/wiki/Shades_of_green
	//		int color = Color.argb(255, 0, 158, 96);
	//		int color2 = lighter(color, 1.4f);
	//		c.random(color, 0.6);
	//		int size = width;
	//		int center = size / 2;
	//		int fontSize = center / 3;
	//		int up = center / 2;
	//		int down = center + up;
	//		int[] colors = { Color.BLACK, Color.WHITE, color2 };
	//
	//		int[][] pos = { { center, up }, { up, center }, { down, center },
	//				{ center, down } };
	//		for (int i = 0; i < sColors.length; i++) {
	//			String c1 = sColors[i];
	//			int[] p = pos[i];
	//			for (int j = 0; j < colors.length; j++) {
	//				int col = colors[j];
	//				int x = p[0];
	//				int y = p[1];
	//				if (j == 0) {
	//					x -= 2;
	//					y -= 2;
	//				} else if (j == 1) {
	//					x += 2;
	//					y += 2;
	//				}
	//				c.drawText(x, y, fontSize, c1, col, Align.CENTER, Align.CENTER);
	//				drawText(c, size, x - center, y - center, fontSize, c1, col);
	//				drawText(c, size, x + center, y + center, fontSize, c1, col);
	//				drawText(c, size, x + center, y - center, fontSize, c1, col);
	//				drawText(c, size, x - center, y + center, fontSize, c1, col);
	//
	//			}
	//		}
	//		c.copyTo(pBmp);
	//		c.recycle();
	//	}

	public static void getBackgroundBitmap(Bitmap bitmap) {
		int height = bitmap.getHeight();
		G2dColor col = G2dColor.getDefaultColor();

		for (int y = 0; y < height; y++) {
			float dx = 3 - (y * 3f / height);
			int color = col.getColor(dx);
			for (int x = 0; x < bitmap.getWidth(); x++) {
				bitmap.setPixel(x, y, color);
			}
		}
	}

	public static void getCardsBitmap(Bitmap bmp, int piWidth, int piHeight) {
		int w = piWidth / 13;
		int h = piHeight / 5;

		// create a canvas to draw to
		Canvas c = new Canvas(bmp);
		Paint paint = new Paint();

		c.drawColor(Color.argb(0, 0, 0, 0));
		RectF rectf = new RectF();
		rx = Math.max(2, w / 8f);

		PorterDuffXfermode over = new PorterDuffXfermode(
				PorterDuff.Mode.SRC_OVER);
		PorterDuffXfermode clear = new PorterDuffXfermode(
				PorterDuff.Mode.DST_IN);
		paint.setXfermode(over);
		int white = Color.argb(255, 255, 255, 248);
		int white2 = Color.argb(128, 0, 0, 0);
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 5; j++) {
				rectf.set(i * w + 1, j * h + 1, (i + 1) * w - 2, (j + 1) * h
						- 2);

				paint.setStyle(Style.FILL);
				if (j == 4 && i >= 3) {
					paint.setColor(white2);
				} else {
					paint.setColor(white);
				}
				c.drawRoundRect(rectf, rx, rx, paint);

				paint.setStyle(Style.STROKE);
				if (j == 4 && i >= 3) {
					paint.setColor(white);
				} else {
					paint.setXfermode(clear);
					paint.setColor(Color.argb(0, 0, 0, 0));
					c.drawRoundRect(rectf, rx, rx, paint);
					paint.setXfermode(over);
					paint.setColor(white2);
				}
				c.drawRoundRect(rectf, rx, rx, paint);
			}
		}

		paint.setTextSize(h / 5);
		Rect bounds = new Rect();
		Rect boundColor = new Rect();

		c.save();

		// draw the values
		for (int j = 0; j < sColors.length; j++) {
			if (j == 0) {
				paint.setColor(Color.BLACK);
			} else if (j == 2) {
				paint.setColor(Color.RED);
			}

			String sColor = sColors[j];
			paint.getTextBounds(sColor, 0, sColor.length(), boundColor);
			for (int i = 0; i < sValues.length; i++) {
				String sValue = sValues[i];
				paint.getTextBounds(sValue, 0, sValue.length(), bounds);

				c.drawText(sValue, i * w + rx, (j * h) + bounds.height() + rx,
						paint);
				c.drawText(sColor, (i + 1) * w - rx - boundColor.width(),
						(j * h) + boundColor.height() + rx, paint);
			}
		}

		// draw the values rotated
		c.rotate(180, piWidth / 2, piHeight / 2);
		for (int j = 1; j <= sColors.length; j++) {
			if (j == 3) {
				paint.setColor(Color.BLACK);
			} else if (j == 1) {
				paint.setColor(Color.RED);
			}

			String sColor = sColors[sColors.length - j];
			paint.getTextBounds(sColor, 0, sColor.length(), boundColor);
			for (int i = 0; i < sValues.length; i++) {
				String sValue = sValues[sValues.length - 1 - i];
				paint.getTextBounds(sValue, 0, sValue.length(), bounds);

				c.drawText(sValue, i * w + rx, (j * h) + bounds.height() + rx,
						paint);
				c.drawText(sColor, (i + 1) * w - rx - boundColor.width(),
						(j * h) + boundColor.height() + rx, paint);

			}
		}

		c.restore();
		// draw additional values
		paint.setTextSize(h / 2);
		String[] sAddValues = { "A" };
		for (int i = 0; i < sAddValues.length; i++) {
			String sValue = sAddValues[i];
			paint.getTextBounds(sValue, 0, sValue.length(), bounds);

			paint.setColor(Color.argb(0, 0, 0, 0));
			paint.setXfermode(clear);
			c.drawText(sValue, (i + 4) * w + (w - bounds.width()) / 2, (4 * h)
					+ bounds.height() + (h - bounds.height()) / 2, paint);
			paint.setXfermode(over);
			paint.setColor(Color.argb(64, 128, 128, 126));
			c.drawText(sValue, (i + 4) * w + (w - bounds.width()) / 2, (4 * h)
					+ bounds.height() + (h - bounds.height()) / 2, paint);
		}

	}

	private static int lighter(int color, float f) {
		int r = Math.min(255, (int) (Color.red(color) * f));
		int g = Math.min(255, (int) (Color.green(color) * f));
		int b = Math.min(255, (int) (Color.blue(color) * f));
		return Color.argb(Color.alpha(color), r, g, b);
	}
}
