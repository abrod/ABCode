package de.brod.tools.cardmaniac.gui;

import java.util.ArrayList;
import java.util.Collections;

import android.graphics.Rect;

public class Hand {

	private static int maxx, maxw, maxh;
	private static int[] yPos;
	private static float posX;
	private static float dx;

	public static Hand create(int iMaxId, float x, int y) {
		return create(iMaxId, 0, x, y, x, y);
	}

	public static Hand create(int iMaxId, int piMaxCount, float x, int piY1,
			float x3, int piY2) {
		Hand hand = new Hand((iMaxId + 1) * 1000, piMaxCount, (int) (posX + dx
				* x), yPos[piY1], (int) (posX + dx * x3), yPos[piY2]);
		return hand;
	}

	public static void init(int cntX, int minSize, Rect drawArea,
			boolean... pHeights) {
		int width = drawArea.width();
		int height = drawArea.height();

		maxx = cntX;
		maxw = width;
		maxh = height;

		// prepare the heights

		float heightKeep = Card.cellHeight;

		dx = minSize * 1f / cntX;
		//		if (width > height) {
		//			dx *= 1.3f;
		//		}
		posX = width / 2 - (dx * (cntX - 1)) / 2;

		// set y-positions
		int cntGrap = 0;
		int cntKeep = 0;
		for (boolean b : pHeights) {
			if (b) {
				cntGrap++;
			} else {
				cntKeep++;
			}
		}

		yPos = new int[pHeights.length];

		int posY = drawArea.top;
		float heightGrab = 0;
		if (cntGrap > 0) {
			heightGrab = (height - heightKeep * cntKeep) / cntGrap;
		}

		boolean bTop = true;
		for (int i = 0; i < pHeights.length; i++) {
			if (pHeights[i]) {
				if (i + 1 == pHeights.length) {
					bTop = false;
				}
				if (bTop) {
					yPos[i] = (int) (posY + heightKeep / 2);
				} else {
					yPos[i] = (int) (posY + heightGrab - heightKeep / 2);
				}
				posY += heightGrab;
				bTop = false;
			} else {
				yPos[i] = (int) (posY + heightKeep / 2);
				posY += heightKeep;
				bTop = true;
			}

		}
	}

	private int cnt, x1, y1, x2, y2;
	private ArrayList<Card> lstCards;
	private int id, type;
	private Card card0;
	private boolean _bOneCardIsSelected = false;

	public Hand(int piId, int piMaxCount, int piX1, int piY1, int piX2, int piY2) {
		setId(piId);
		cnt = piMaxCount;
		x1 = piX1;
		y1 = piY1;
		x2 = piX2;
		y2 = piY2;
		lstCards = new ArrayList<Card>();
		card0 = createCard(3, 4);
		card0.setMoveable(false);
	}

	public void addCard(Card card) {
		Hand cardHand = card.getHand();
		// remove card from other hand
		if (cardHand != null && this != cardHand) {
			cardHand.lstCards.remove(card);
		}
		// set and add the hand
		card.setHand(this);
		lstCards.add(card);
	}

	public void checkSelected() {
		_bOneCardIsSelected = false;
		for (int i = 1; i < lstCards.size(); i++) {
			if (lstCards.get(i).isSelected()) {
				_bOneCardIsSelected = true;
			}
		}
	}

	public void clearCards() {
		lstCards.clear();
		lstCards.add(card0);
	}

	public ArrayList<Card> create52Cards() {
		ArrayList<Card> lst = new ArrayList<Card>();
		for (int i = 0; i < 13; i++) {
			for (int j = 0; j < 4; j++) {
				lst.add(createCard(i, j));
			}
		}
		Collections.shuffle(lst);
		return lst;
	}

	public Card createCard(int value, int color) {
		Card r = Card.createCard(x1, y1, value, color);
		r.setHand(this);
		lstCards.add(r);
		organize();
		return r;
	}

	public ArrayList<Card> getAllCards() {
		return lstCards;
	}

	public int getCardCount() {
		return lstCards.size() - 1;
	}

	public int getId() {
		return id;
	}

	public Card getLastCard() {
		if (lstCards.size() > 1) {
			return lstCards.get(lstCards.size() - 1);
		}
		return null;
	}

	public Card[] getPlayingCards() {
		Card[] ret = new Card[lstCards.size() - 1];
		for (int i = 0; i < ret.length; i++) {
			ret[i] = lstCards.get(i + 1);
		}
		return ret;
	}

	public int getType() {
		return type;
	}

	public void organize() {
		int amnt = Math.max(cnt, lstCards.size() - 1) - 1;
		float dx = 0;
		float dy = 0;
		if (amnt > 0) {
			dx = (x2 - x1) * 1f / amnt;
			dy = (y2 - y1) * 1f / amnt;
		}
		float px = x1;
		float py = y1;
		int i = id;
		if (_bOneCardIsSelected) {
			i += 1000 * 1000;
		}
		for (int j = 0; j < lstCards.size(); j++) {
			Card c = lstCards.get(j);
			c.moveTo(Math.round(px), Math.round(py));
			c.setId(i++);
			if (j > 0) {
				px += dx;
				py += dy;
			}
		}
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setType(int type) {
		this.type = type;
	}
}
