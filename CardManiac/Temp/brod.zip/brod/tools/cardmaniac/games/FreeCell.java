package de.brod.tools.cardmaniac.games;

import java.util.ArrayList;

import de.brod.tools.cardmaniac.gui.Card;
import de.brod.tools.cardmaniac.gui.Hand;

public class FreeCell extends Game {

	@Override
	int getAmountOfHorizonzalCards() {
		return 8;
	}

	@Override
	boolean[] getAutoFillCardLines(boolean pbLandscape) {
		if (pbLandscape) {
			return new boolean[] { false, false, false, true, true };
		}
		return new boolean[] { false, true, true };
	}

	@Override
	public String getTitle() {
		return "FreeCell";
	}

	@Override
	void initHands(ArrayList<Hand> lstHand, boolean pbLandscape) {
		if (pbLandscape) {
			for (int j = 0; j < 8; j++) {
				Hand h;
				if (j >= 4) {
					h = Hand.create(j, 8.2f, j - 4);
					h.setType(2);
					Card c0 = h.getAllCards().get(0);
					c0.setImgCell(4, 4);
				} else {
					h = Hand.create(j, -1.2f, j);
					h.setType(1);
				}
				lstHand.add(h);
				h = Hand.create(j, 13, j, 0, j, 4);
				h.setType(0);
				lstHand.add(h);
			}
		} else {
			for (int j = 0; j < 8; j++) {
				Hand h = Hand.create(j, j, 0);
				if (j >= 4) {
					Card c0 = h.getAllCards().get(0);
					c0.setImgCell(4, 4);
					h.setType(2);
				} else {
					h.setType(1);
				}

				lstHand.add(h);
				h = Hand.create(j, 13, j, 1, j, 2);
				h.setType(0);
				lstHand.add(h);
			}
		}

	}

	private boolean matches(Card card, Card cLast) {
		if (cLast == null) {
			return true;
		}
		if (card.getCellX() - 1 != cLast.getCellX()) {
			return false;
		}
		int c1 = card.getCellY() / 2;
		int c2 = cLast.getCellY() / 2;
		// color has to rotate
		if (c1 == c2) {
			return false;
		}
		return true;
	}

	@Override
	public boolean mouseDown(Card c) {
		Hand hand = c.getHand();
		Card[] playingCards = hand.getPlayingCards();
		Card cLast = null;
		for (int i = playingCards.length - 1; i >= 0; i--) {
			Card card = playingCards[i];
			if (matches(card, cLast)) {
				card.setMoving(true);
				if (card == c) {
					break;
				}
			} else {
				break;
			}
			cLast = card;
		}

		return true;
	}

	@Override
	public boolean mouseUp(ArrayList<Card> lstMove, Hand hand) {
		if (lstMove.size() > 0) {
			Card firstCard = lstMove.get(0);
			Hand handMove = firstCard.getHand();
			if (hand != handMove) {
				boolean bOk = true;
				// check hand
				if (hand.getType() == 0) {
					// check only if there are cards
					if (hand.getCardCount() > 0) {
						while (lstMove.size() > 0
								&& !matches(hand.getLastCard(), lstMove.get(0))) {
							Card card0 = lstMove.remove(0);
							card0.setMoving(false);
							card0.setSelected(false);
						}
					}
				} else {
					// top hand
					if (lstMove.size() > 1) {
						// only one card may be added
						bOk = false;
					} else if (hand.getType() == 1) {
						// there is place for only one card
						if (hand.getCardCount() >= 1) {
							bOk = false;
						}
					} else if (hand.getType() == 2) {
						// check the top cart
						Card topCard = hand.getLastCard();
						if (topCard != null) {
							if (topCard.getColor() != firstCard.getColor()) {
								bOk = false;
							} else if (topCard.getValue() + 1 != firstCard
									.getValue()) {
								bOk = false;
							}
						} else if (firstCard.getValue() != 0) {
							bOk = false;
						}
					}
				}
				if (!bOk) {
					for (Card card : lstMove) {
						card.setMoving(false);
						card.setSelected(false);
					}
				} else {
					for (Card card : lstMove) {
						hand.addCard(card);
					}
				}
				return true;
			}
		}
		return false;
	}

	@Override
	void newGame(ArrayList<Hand> lstHand) {
		Hand hand0 = lstHand.get(0);
		int iPos = 1;
		for (Card card : hand0.create52Cards()) {
			lstHand.get(iPos).addCard(card);
			iPos = (iPos + 2) % lstHand.size();
		}

	}

}
