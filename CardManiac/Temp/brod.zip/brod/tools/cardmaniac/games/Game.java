package de.brod.tools.cardmaniac.games;

import java.util.ArrayList;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Rect;
import de.brod.tools.cardmaniac.gui.Card;
import de.brod.tools.cardmaniac.gui.Hand;

public abstract class Game {

	ArrayList<Hand> hands;

	abstract int getAmountOfHorizonzalCards();

	abstract boolean[] getAutoFillCardLines(boolean pbLandscape);

	public Bitmap getIcon(int titleBarHeight) {
		return null;
	}

	public abstract String getTitle();

	public void init(boolean b, ArrayList<Hand> lstHand, int minSize,
			Rect drawArea, Resources resources) {

		int width = drawArea.width();
		int height = drawArea.height();

		boolean bLandscape = width > height;

		// set the member
		hands = lstHand;

		int cntX = getAmountOfHorizonzalCards();

		boolean[] heights = getAutoFillCardLines(bLandscape);

		// init the images
		Card.init(cntX, minSize, resources);

		Hand.init(cntX, minSize, drawArea, heights);

		// create a hands
		initHands(lstHand, bLandscape);

		// start a new Game
		newGame();

	}

	abstract void initHands(ArrayList<Hand> lstHand, boolean pbLandscape);

	public abstract boolean mouseDown(Card c);

	public abstract boolean mouseUp(ArrayList<Card> lstMove, Hand hand);

	public void newGame() {
		for (Hand hand : hands) {
			hand.clearCards();
		}
		newGame(hands);
	}

	abstract void newGame(ArrayList<Hand> hands2);
}
