package de.brod.gui2d;

import android.util.Log;

public class G2dLog {

	private static String tag = "Application";

	public static void info(String msg) {
		Log.i(tag, msg);
	}

	protected static void setTag(String string) {
		tag = string;
	}

}
