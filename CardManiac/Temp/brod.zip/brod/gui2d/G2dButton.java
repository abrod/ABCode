package de.brod.gui2d;

import android.content.res.Resources;
import de.brod.tools.cardmaniac.R;

public class G2dButton extends G2dItem {

	public static enum Position {
		TOP, BOTTOM, ABSOLUTE
	}

	public enum Types {
		BLUETOOTH(0), STATISTCS(1), WIFI(2), NOSOUND(3), SOUND(4), STOP(5), //
		ATTENTION(6), YES(7), RIGHT(8), NO(9), UP(10), DOWN(11), //
		LEFT(12), NEXT(13), PREVIEW(14), RELOAD(15), INFO(16), HELP(17), //
		SEARCH(18), SETTINGS(19), STAR_ON(20), STAR_OFF(21), LIST(22), DELETE(
				23), //
		UNDO(24), REDO(25), PEOPLE2(26), PEOPLE3(27), PEOPLE1(28), MENU(29);

		private int _idx;

		Types(int idx) {
			_idx = idx;
		}

		public G2dButton create() {
			return new G2dButton(this);
		}
	}

	private static G2dImage g2dIcons;
	private static int _titleBarHeight;

	public static void init(Resources resources, int titleBarHeight) {
		_titleBarHeight = titleBarHeight;
		g2dIcons = G2dImage.get("icons", 0, 0, resources, R.drawable.icons, 12,
				12, 5);
	}

	private boolean bActive;
	private int _item;
	private Types _type;
	private Position position = Position.BOTTOM;

	private G2dButton(Types piItem) {
		super(0, 0, _titleBarHeight, _titleBarHeight);
		_type = piItem;
		_item = piItem._idx;
		setActive(true);
	}

	public Position getPosition() {
		return position;
	}

	public Types getType() {
		return _type;
	}

	public boolean isActive() {
		return bActive;
	}

	public G2dButton setActive(boolean b) {
		bActive = b;
		int x = _item % 6;
		if (!bActive) {
			x = (x + 6) % 12;
		}
		setImage(g2dIcons, x, _item / 6);
		return this;
	}

	public G2dButton setPosition(Position position) {
		this.position = position;
		return this;
	}

	@Override
	public void setSelected(boolean b) {
		super.setSelected(b);
		if (b) {
			setBackgroundColor(G2dColor.getDefaultColor().getColor(2));
		} else {
			setBackgroundColor(0);
		}
	}

}
