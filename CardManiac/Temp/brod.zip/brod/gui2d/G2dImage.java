package de.brod.gui2d;

import java.util.Hashtable;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;

public class G2dImage {

	private static Hashtable<String, G2dImage> ht = new Hashtable<String, G2dImage>();

	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		G2dLog.info("calculateInSampleSize " + width + "x" + height + " in "
				+ reqWidth + "x" + reqHeight);
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			// Calculate ratios of height and width to requested height and
			// width
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);

			// Choose the smallest ratio as inSampleSize value, this will
			// guarantee
			// a final image with both dimensions larger than or equal to the
			// requested height and width.
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}

		return inSampleSize;
	}

	public static void clear(String sKey) {
		G2dImage remove = ht.remove(sKey);
		if (remove != null) {
			Bitmap bitmap = remove.getBitmap();
			if (bitmap != null) {
				bitmap.recycle();
			}
		}
	}

	public static void clearAllImages() {
		String[] keySet = ht.keySet().toArray(new String[0]);
		for (String sKey : keySet) {
			clear(sKey);
		}
	}

	public static boolean contains(String string) {
		return ht.contains(string);
	}

	public static Bitmap decodeSampledBitmapFromResource(Resources res,
			int resId, int reqWidth) {

		// First decode with inJustDecodeBounds=true to check dimensions
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		options.inDither = true;
		options.inScaled = false; /* Flag for no scalling */
		BitmapFactory.decodeResource(res, resId, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqWidth);
		G2dLog.info("--> decodeResource with inSampleSize="
				+ options.inSampleSize);

		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeResource(res, resId, options);
	}

	public static G2dImage get(String psKey, int piWidth, int piHeight,
			int cntX, int cntY) {
		G2dImage g2dImage = ht.get(psKey);
		if (g2dImage != null) {
			return g2dImage;
		}
		//
		Bitmap pBmp = Bitmap.createBitmap(piWidth, piHeight, Config.ARGB_8888);
		// int[] pBmp = new int[piWidth * piHeight];
		// create a new image
		g2dImage = new G2dImage(pBmp, cntX, cntY, piWidth, piHeight, piWidth
				/ cntX, piHeight / cntY);
		ht.put(psKey, g2dImage);
		return g2dImage;
	}

	public static G2dImage get(String psKey, int piScreenWidth,
			int piScreenHeight, Resources resources, int piId, int piCntX,
			int cntX, int cntY) {
		// free memory
		System.gc();

		G2dImage g2dImage = ht.get(psKey);
		if (g2dImage != null) {
			return g2dImage;
		}
		Bitmap pBmp = BitmapFactory.decodeResource(resources, piId);

		int iScreenWidth;
		int iScreenHeight;
		if (piScreenWidth > 0 && piScreenWidth != pBmp.getWidth()) {
			iScreenWidth = piScreenWidth;
			iScreenHeight = piScreenHeight;
			Bitmap pBmpResize = getResizedBitmap(pBmp, iScreenWidth,
					iScreenHeight);
			pBmp.recycle();
			pBmp = pBmpResize;
		} else {
			iScreenWidth = pBmp.getWidth();
			iScreenHeight = pBmp.getWidth();
		}

		int w = pBmp.getWidth();
		int h = pBmp.getHeight();

		int minSize = Math.min(iScreenWidth, iScreenHeight);
		int minSize4Cell = minSize;
		if (piCntX > 1 && cntX > 1) {
			minSize4Cell = minSize * cntX / piCntX;
		}
		G2dLog.info("Create Bitmap: " + psKey + " (calcWidth=" + minSize4Cell
				+ ")");

		// create a new image
		int iCellWidth = minSize4Cell / cntX;
		int iCellHeight = minSize4Cell * h / w / cntY;
		G2dLog.info("... Size is " + w + "x" + h + " [" + iCellWidth + "x"
				+ iCellHeight + "]");
		g2dImage = new G2dImage(pBmp, cntX, cntY, w, h, iCellWidth, iCellHeight);
		ht.put(psKey, g2dImage);
		return g2dImage;
	}

	public static Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth) {

		int width = bm.getWidth();
		int height = bm.getHeight();

		float scaleWidth = ((float) newWidth) / width;
		float scaleHeight = ((float) newHeight) / height;

		// create a matrix for the manipulation
		Matrix matrix = new Matrix();

		// resize the bit map

		matrix.postScale(scaleWidth, scaleHeight);
		// recreate the new Bitmap

		Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height,
				matrix, false);

		return resizedBitmap;
	}

	private Bitmap bmp;
	private int width, height, x, y, cx, cy;
	private float dx, dy;

	private Canvas canvas;
	private int[] pixels;

	private G2dImage(Bitmap pBmp, int cntX, int cntY, int pWidth, int pHeight,
			int piCellWidth, int piCellHeight) {
		bmp = pBmp;
		width = pWidth;
		height = pHeight;
		x = cntX;
		y = cntY;
		cx = piCellWidth;
		cy = piCellHeight;
		dx = 1f * width / x;
		dy = 1f * height / y;
		if (pBmp.isMutable()) {
			canvas = new Canvas(pBmp);
		} else {
			canvas = null;
		}

	}

	public void consumeBitmap() {
		if (bmp == null) {
			return;
		}
		pixels = new int[width * height];
		bmp.getPixels(pixels, 0, width, 0, 0, width, height);
		bmp.recycle();
		bmp = null;
	}

	public void drawColor(int color) {
		if (canvas != null) {
			canvas.drawColor(color);
		}
	}

	public void drawTo(Canvas pCanvas, Rect imgRect, Rect target, Paint paint) {
		if (bmp == null) {
			int offset = imgRect.left;drrgiroeig
			int stride=this.width;
			pCanvas.drawBitmap(pixels, offset, stride, target.left, target.top, target.width(), target.height(), true,
					paint);
		} else {
			pCanvas.drawBitmap(bmp, imgRect, target, paint);
			// canvas.drawBitmap(bmp, 0, width, left, top, width, height, true,
			// paint);
		}
	}

	public Bitmap getBitmap() {
		return bmp;
	}

	public int getCellHeight() {
		return cy;
	}

	public int getCellWdith() {
		return cx;
	}

	public int getHeight() {
		return height;
	}

	public int getWidth() {
		return width;
	}

	public void setRect(Rect imgRect, int piImgX, int piImgY) {
		int x1 = Math.round(piImgX * dx);
		int y1 = Math.round(piImgY * dy);
		int x2 = (int) (x1 + dx) - 1;
		int y2 = (int) (y1 + dy) - 1;
		imgRect.set(x1, y1, x2, y2);
	}

}
