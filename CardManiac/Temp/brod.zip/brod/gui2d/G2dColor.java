package de.brod.gui2d;

import android.graphics.Color;

public class G2dColor {

	public static enum Type {
		BLACK("#333333", "#AAAAAA"), BLUE("#0099CC", "#33B5E5"), PURPLE(
				"#9933CC", "#AA66CC"), GREEN("#669900", "#99CC00"), ORANGE(
				"#FF8800", "#FFBB33"), RED("#CC0000", "#FF4444");

		private G2dColor g2dColor;

		Type(String dark, String light) {
			g2dColor = new G2dColor(dark, light);
		}

		public G2dColor getColor() {
			return g2dColor;
		}
	}

	private static G2dColor DEFAULT = null;

	public static G2dColor getDefaultColor() {
		if (DEFAULT == null) {
			DEFAULT = Type.BLUE.getColor();
		}
		return DEFAULT;
	}

	public static void setDefaultColor(Type pType) {
		DEFAULT = pType.getColor();
	}

	public static void setRandomColor() {
		Type[] values = Type.values();
		setDefaultColor(values[(int) (Math.random() * values.length)]);
	}

	private int[] _dark, _light;

	private int idark, ilight;

	private G2dColor(String dark, String light) {
		idark = Color.parseColor(dark);
		ilight = Color.parseColor(light);

		_dark = new int[] { Color.red(idark), Color.green(idark),
				Color.blue(idark) };
		_light = new int[] { Color.red(ilight), Color.green(ilight),
				Color.blue(ilight) };
	}

	public int getColor() {
		return idark;
	}

	public int getColor(float pct) {
		if (pct <= 1) {
			return Color.rgb((int) (_dark[0] * pct), (int) (_dark[1] * pct),
					(int) (_dark[2] * pct));
		}
		if (pct <= 2) {
			pct = 2 - pct;
			float pct2 = 1 - pct;
			return Color.rgb((int) (_dark[0] * pct + _light[0] * pct2),
					(int) (_dark[1] * pct + _light[1] * pct2), (int) (_dark[2]
							* pct + _light[2] * pct2));
		}
		pct = 3 - pct;
		float pct2 = 1 - pct;
		return Color.rgb((int) (_light[0] * pct + 255 * pct2), (int) (_light[1]
				* pct + 255 * pct2), (int) (_light[2] * pct + 255 * pct2));
	}

	public int getLightColor() {
		return ilight;
	}
}
