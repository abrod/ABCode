package de.brod.gui2d;

import java.util.ArrayList;
import java.util.Collections;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import de.brod.gui2d.G2dButton.Position;
import de.brod.gui2d.G2dButton.Types;

public abstract class G2dView<ITEM extends G2dItem> extends View {

	protected int width;
	protected int height;
	private Bitmap bitmap;
	protected Canvas canvas;
	private Paint paint;
	private ArrayList<ITEM> lstItems = new ArrayList<ITEM>();
	private ArrayList<ITEM> lstDrawItems = new ArrayList<ITEM>();
	private G2dContext context;
	Rect tileRect;
	private ArrayList<ITEM> lstMoving = new ArrayList<ITEM>();
	private int statusBarHeight;
	protected int titleBarHeight;
	private ArrayList<G2dButton> lstButtons;
	private G2dButton selectedButton;
	private boolean bMouseMove = false;

	public G2dView(G2dContext pContext) {
		super(pContext);
		G2dLog.info("> Create View " + getClass().getName());

		G2dColor.setRandomColor();

		G2dImage.clearAllImages();

		tileRect = new Rect();
		context = pContext;
		DisplayMetrics displayMetrics = pContext.getResources()
				.getDisplayMetrics();

		width = displayMetrics.widthPixels;
		height = displayMetrics.heightPixels;

		statusBarHeight = (int) Math.ceil(25 * displayMetrics.density);
		titleBarHeight = statusBarHeight * 3 / 2;

		System.out.println("height:" + titleBarHeight);

		// init the buttons
		G2dButton.init(getResources(), titleBarHeight);

		lstButtons = new ArrayList<G2dButton>();

		initButtons(lstButtons);

		oranizeButtons();

		Config config = Config.ARGB_8888;
		// create a bitmap
		bitmap = Bitmap.createBitmap(width, height, config);
		canvas = new Canvas(bitmap);

		paint = new Paint();

		// init the view
		initView(lstItems);

		// update the view
		update();
	}

	public void clear(int color) {
		canvas.drawColor(color);
	}

	protected abstract void drawBackGround();

	public void drawLine(int x, int y, int x2, int y2) {
		canvas.drawLine(x, y, x2, y2, paint);
	}

	public void drawText(String string, int x, int y) {
		canvas.drawText(string, x, y, paint);
	}

	public void drawTitle(String psTitle) {
		int hg = titleBarHeight;
		int hgBottom = height - hg;

		boolean bTwoTitle = width < height;
		// make black
		G2dColor defaultColor = G2dColor.getDefaultColor();
		paint.setColor(defaultColor.getColor());
		canvas.drawRect(0, 0, width, hg, paint);
		if (bTwoTitle) {
			canvas.drawRect(0, hgBottom, width, height, paint);
		}

		canvas.drawBitmap(getIcon(), hg / 2, 0, paint);
		int fontColor = defaultColor.getLightColor();
		paint.setColor(fontColor);
		canvas.drawLine(0, hg, width, hg, paint);
		if (bTwoTitle) {
			canvas.drawLine(0, hgBottom, width, hgBottom, paint);
		}

		setFontHeight(psTitle, hg * 0.5f);
		drawText(psTitle, (int) (hg * 1.5), (int) (hg * 0.75f));

		// draw the buttons
		for (G2dButton button : lstButtons) {
			button.draw(canvas);
		}
	}

	protected abstract Bitmap getIcon();

	protected abstract String getTitle();

	protected void initButtons(ArrayList<G2dButton> plstButtons) {
		G2dButton left = G2dButton.Types.PREVIEW.create();
		plstButtons.add(left.setPosition(Position.ABSOLUTE));
		left.setWidth(titleBarHeight / 2);
		left.setHeight(titleBarHeight / 2);
		left.moveTo(titleBarHeight / 4, titleBarHeight / 2);

		plstButtons
				.add(G2dButton.Types.MENU.create().setPosition(Position.TOP));
		plstButtons
				.add(G2dButton.Types.HELP.create().setPosition(Position.TOP));
	}

	protected abstract void initView(ArrayList<ITEM> pLstItems);

	public boolean mouseDown(int eventX, int eventY) {
		boolean bUpdate = false;
		// de-select all moving items
		for (ITEM item : lstItems) {
			if (item.isMoving()) {
				item.setMoving(false);
				bUpdate = true;
			}
		}
		// reset
		lstMoving.clear();
		selectedButton = null;
		// check the buttons
		for (G2dButton button : lstButtons) {
			if (button.touch(eventX, eventY)) {
				if (button.isActive()) {
					button.setSelected(true);
					selectedButton = button;
				}
				return true;
			}
		}

		// select the last element
		for (int i = lstItems.size() - 1; i >= 0; i--) {
			ITEM rectItem = lstItems.get(i);
			if (rectItem.touch(eventX, eventY)) {
				if (mouseDown(rectItem)) {
					// add all selected
					for (ITEM item : lstItems) {
						if (item.isMoving()) {
							// add to selected list
							lstMoving.add(item);
							// set the touch values
							item.touch(eventX, eventY);
						}
					}
					if (!lstMoving.contains(rectItem)) {
						lstMoving.clear();
					}
					if (lstMoving.size() == 0) {
						Collections.sort(lstItems);
					}
				}
				return true;
			}
		}
		// de-select all items if touched anywhere
		for (ITEM item : lstItems) {
			item.setSelected(false);
		}
		return bUpdate;
	}

	protected abstract boolean mouseDown(ITEM rectItem);

	public boolean mouseMove(int eventX, int eventY) {
		if (selectedButton == null && lstMoving.size() > 0) {
			bMouseMove = true;
			for (ITEM sel : lstMoving) {
				sel.moveTouch(eventX, eventY);
			}
			return true;
		}
		return false;
	}

	protected abstract void mouseUp(ArrayList<ITEM> lstMoving2, ITEM moveTo);

	public boolean mouseUp(int eventX, int eventY) {
		if (selectedButton != null) {
			if (selectedButton.touch(eventX, eventY)) {
				pressButton(selectedButton.getType());
			}
			selectedButton.setSelected(false);
			return true;
		}
		if (lstMoving.size() > 0) {
			for (ITEM sel : lstMoving) {
				sel.setMoving(false);
			}
			ITEM moveTo = null;
			for (ITEM item : lstItems) {
				if (!lstMoving.contains(item) && item.touch(eventX, eventY)) {
					moveTo = item;
					break;
				}
			}
			mouseUp(lstMoving, moveTo);

			lstMoving.clear();
			Collections.sort(lstItems);
			return true;
		}
		return true;
	}

	public void onDestroy() {
		// cleanup
		bitmap.recycle();
		// Destroy the images
		G2dImage.clearAllImages();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.drawBitmap(bitmap, 0, 0, null);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		int eventX = (int) event.getX();
		int eventY = (int) event.getY();
		bMouseMove = false;
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			if (mouseDown(eventX, eventY)) {
				// Schedules a repaint.
				update();
				invalidate();
			}
			break;
		case MotionEvent.ACTION_MOVE:
			if (mouseMove(eventX, eventY)) {
				// Schedules a repaint.
				update();
				invalidate();
			}
			break;
		case MotionEvent.ACTION_UP:
			if (mouseUp(eventX, eventY)) {
				// Schedules a repaint.
				update();
				invalidate();
			}
			break;
		default:
			return false;
		}

		return true;
	}

	private void oranizeButtons() {
		int y = titleBarHeight / 2;
		int x = width - titleBarHeight / 2;
		int iCntBottom = 0;
		for (G2dButton button : lstButtons) {
			if (button.getPosition().equals(Position.TOP)) {
				button.moveTo(x, y);
				x -= titleBarHeight;
			} else if (button.getPosition().equals(Position.BOTTOM)) {
				iCntBottom++;
			}
		}
		if (iCntBottom > 0) {
			int dx = titleBarHeight;
			if (width < height) {
				y = height - titleBarHeight / 2;
				dx = width / iCntBottom;
				x = width - dx / 2;
			} else {
				x -= dx / 2;
			}
			for (int i = lstButtons.size() - 1; i >= 0; i--) {
				G2dButton button = lstButtons.get(i);
				if (button.getPosition().equals(Position.BOTTOM)) {
					button.moveTo(x, y);
					x -= dx;
				}
			}
		}
	}

	public void pressButton(Types type) {
		if (type.equals(Types.HELP)) {
			// show help
		} else if (type.equals(Types.MENU)) {
			// show Menu
		}
	}

	public void setColor(int color) {
		paint.setColor(color);
	}

	public void setFontHeight(String psText, float hg) {
		paint.setTextSize(hg);
		Rect bounds = new Rect();
		paint.getTextBounds(psText, 0, psText.length(), bounds);
		paint.setTextSize(hg * hg / bounds.height());

	}

	public void tile(G2dImage img, int x, int y, int wd, int hg) {

		int w = img.getWidth();
		int h = img.getHeight();

		Rect imgRect = new Rect(0, 0, w, h);

		for (int top = 0; top < hg; top += h) {
			for (int left = 0; left < wd; left += w) {
				tileRect.set(left, top, left + w, top + h);
				img.drawTo(canvas, imgRect, tileRect, paint);
			}
		}

	}

	protected void update() {

		clear(Color.GRAY);

		// draw the background
		drawBackGround();

		//		if (bMouseMove) {
		//			// draw the items
		//			for (ITEM item : lstItems) {
		//				if (!lstMoving.contains(item)) {
		//					item.draw(canvas);
		//				}
		//			}
		//			for (ITEM item : lstMoving) {
		//				item.draw(canvas);
		//			}
		//		} else {

		ArrayList<ITEM> lstDraw;
		if (lstMoving.size() > 0) {
			lstDraw = lstDrawItems;
			lstDraw.clear();
			for (ITEM item : lstItems) {
				if (!lstMoving.contains(item)) {
					lstDraw.add(item);
				}
			}
			lstDraw.addAll(lstMoving);
		} else {
			lstDraw = lstItems;
		}

		for (int i = 0; i < lstDraw.size(); i++) {
			ITEM item = lstDraw.get(i);
			if (item.isSelected()) {
				int iMax = i;
				for (int j = i; j < lstDraw.size(); j++) {
					ITEM item1 = lstDraw.get(j);
					if (item1.isSelected()) {
						iMax = j;
						item1.drawBorder(canvas);
					} else {
						break;
					}
				}
				while (i <= iMax) {
					ITEM item1 = lstDraw.get(i);
					item1.draw(canvas);
					i++;
				}
				i--;
			} else {
				item.draw(canvas);
			}
		}
		//		}

		drawTitle(getTitle());

	}

}
