package de.brod.gui2d;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;

public abstract class G2dItem implements Comparable<G2dItem> {

	private int x;
	private int y;
	private int width, height, width2, height2;
	Paint paint;
	private float angle;
	private int touchX, touchY;
	private boolean moving = false;
	private boolean moveable = true;
	private boolean selected = false;
	private int id;
	private Rect rect;
	private G2dImage img;
	private int imgX, imgY;
	Rect imgRect;
	private int backgroundColorColor = 0;
	private Paint paintBorder;

	public G2dItem(int px, int py, int piWidth, int piHeight) {
		setWidth(piWidth);
		setHeight(piHeight);
		moveTo(px, py);
		paint = new Paint();
		paintBorder = new Paint();
		paintBorder.setColor(Color.BLACK);
		paintBorder.setStyle(Style.STROKE);
	}

	@Override
	public int compareTo(G2dItem another) {
		return id - another.id;
	}

	void draw(Canvas canvas) {
		if (angle == 0f) {
			drawInternal(canvas);
		} else {
			// Saving the canvas and later
			// restoring it so only this
			// image will be rotated.
			canvas.save(Canvas.MATRIX_SAVE_FLAG);

			// rotate around a center
			canvas.rotate(angle, getX(), getY());
			drawInternal(canvas);
			canvas.restore();
		}
	}

	public void drawBorder(Canvas canvas) {
		canvas.drawRect(rect, paintBorder);
	}

	void drawInternal(Canvas canvas) {
		if (backgroundColorColor != 0) {
			paint.setColor(backgroundColorColor);
			canvas.drawRect(rect, paint);
		}
		if (img != null) {
			img.drawTo(canvas, imgRect, rect, paint);
		} else {
			canvas.drawRect(rect, paint);
		}
	}

	public float getAngle() {
		return angle;
	}

	public int getCellX() {
		return imgX;
	}

	public int getCellY() {
		return imgY;
	}

	public int getHeight() {
		return height;
	}

	public int getHeight2() {
		return height2;
	}

	public int getId() {
		return id;
	}

	public Rect getRect() {
		return rect;
	}

	public int getWidth() {
		return width;
	}

	public int getWidth2() {
		return width2;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public boolean isMoveable() {
		return moveable;
	}

	public boolean isMoving() {
		if (!moveable) {
			return false;
		}
		return moving;
	}

	public boolean isSelected() {
		return selected;
	}

	public void moveTo(int px, int py) {
		setX(px);
		setY(py);

		int wd = getWidth2();
		int hg = getHeight2();

		int left = px - wd;
		int top = py - hg;

		int right = px + wd;
		int bottom = py + hg;
		if (rect == null) {
			rect = new Rect();
		}
		int border = 0;
		rect.set(left + border, top + border, right - border, bottom - border);
	}

	public void moveTouch(int eventX, int eventY) {
		int px = eventX - touchX;
		int py = eventY - touchY;
		moveTo(px, py);
	}

	public void setAngle(float angle) {
		this.angle = angle;
	}

	public void setBackgroundColor(int pBackgroundColorColor) {
		backgroundColorColor = pBackgroundColorColor;
	}

	public void setColor(Integer color) {
		LightingColorFilter colorFilter;
		if (color == null) {
			colorFilter = null;
		} else {
			colorFilter = new LightingColorFilter(color.intValue(), 1);
		}
		paint.setColorFilter(colorFilter);

	}

	public void setHeight(int piHeight) {
		this.height = piHeight;
		height2 = piHeight / 2;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setImage(G2dImage image, int piImgX, int piImgY) {
		img = image;
		imgRect = new Rect();
		setImgCell(piImgX, piImgY);
	}

	public void setImgCell(int piImgX, int piImgY) {
		img.setRect(imgRect, piImgX, piImgY);
		imgX = piImgX;
		imgY = piImgY;
	}

	public void setMoveable(boolean moveable) {
		this.moveable = moveable;
	}

	public void setMoving(boolean pbMoving) {
		if (!moveable) {
			moving = false;
		} else {
			this.moving = pbMoving;
		}
	}

	public void setSelected(boolean pbSelected) {
		this.selected = pbSelected;
	}

	public void setWidth(int piWidth) {
		this.width = piWidth;
		width2 = piWidth / 2;
	}

	private void setX(int x) {
		this.x = x;
	}

	private void setY(int y) {
		this.y = y;
	}

	public boolean touch(int eventX, int eventY) {
		touchX = eventX - x;
		touchY = eventY - y;
		if (touchX < -width2 || touchY < -height2) {
			return false;
		}
		if (touchX > width2 || touchY > height2) {
			return false;
		}
		return true;
	}
}
