package de.brod.gui2d;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public abstract class G2dContext extends Activity {

	private G2dView cmView;

	public G2dContext() {
		G2dLog.setTag(this.getClass().getPackage().getName());
	}

	protected abstract G2dView createView();

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		G2dLog.info("> Create Context");

		super.onCreate(savedInstanceState);

		// disable title
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		// make full screen
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);

		cmView = createView();
		setContentView(cmView);

	}

	@Override
	public void onDestroy() {
		G2dLog.info("> Destroy Context");

		// cleanup the view
		cmView.onDestroy();

		super.onDestroy();
	}

}
