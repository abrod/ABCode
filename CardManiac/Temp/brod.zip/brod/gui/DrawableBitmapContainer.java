package de.brod.gui;

import java.util.Arrays;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Rect;

public class DrawableBitmapContainer {
	private Bitmap image;
	private int width, height;
	private int[] pixels;
	private Canvas canvas = null;
	private Paint paint = null;

	public DrawableBitmapContainer(Bitmap pSource) {
		image = pSource.copy(Config.ARGB_8888, true);
		width = image.getWidth();
		height = image.getHeight();
		pixels = new int[width * height];
		image.getPixels(pixels, 0, width, 0, 0, width, height);
	}

	public DrawableBitmapContainer(int w, int h) {
		image = Bitmap.createBitmap(w, h, Config.ARGB_8888);
		width = w;
		height = h;
		pixels = new int[width * height];
	}

	public void clear(int piColor) {
		Arrays.fill(pixels, piColor);
	}

	public DrawableBitmapContainer copy() {
		DrawableBitmapContainer copy = new DrawableBitmapContainer(width,
				height);
		int[] cp = copy.pixels;
		for (int i = 0; i < pixels.length; i++) {
			cp[i] = pixels[i];
		}
		return copy;
	}

	public void copyRect(int x, int y, int w, int h, int x2, int y2) {
		h = Math.min(Math.min(h, height - y2), height - y);
		w = Math.min(Math.min(w, width - x2), width - x);
		for (int i = 0; i < h; i++) {
			int start = x + (y + i) * width;
			int end = x2 + (y2 + i) * width;
			for (int j = 0; j < w; j++) {
				if (end >= pixels.length) {
					break;
				}
				pixels[end] = pixels[start];
				start++;
				end++;
			}
		}
	}

	public void copyTo(Bitmap pBmp) {

		pBmp.setPixels(pixels, 0, width, 0, 0, width, height);
	}

	public void drawCircle(int x, int y, int r, int color) {
		for (int i = -r; i <= r; i++) {
			double c = 1d * i / r;
			c = Math.sqrt(1 - c * c) * r;
			int px = (int) (x - c);
			px += (y + i) * width;
			for (int j = 0; j < c * 2; j++) {
				pixels[px] = color;
				px++;
			}
		}
	}

	private void drawLine(float x, float y, float x2, float y2, int color) {
		float dx = x2 - x;
		float dy = y2 - y;
		float max = Math.max(Math.abs(dx), Math.abs(dy));
		if (max > 0) {
			dx = dx / max;
			dy = dy / max;
		}
		for (int i = 0; i <= max; i++) {
			setPixel(Math.round(x), Math.round(y), color);
			x += dx;
			y += dy;
		}

	}

	public void drawRect(int x, int y, int wd, int hg, int color) {
		for (int j = 0; j < hg; j++) {
			int pos = (y + j) * width + x;
			for (int i = 0; i < wd; i++) {
				pixels[pos] = color;
				pos++;
			}
		}
	}

	public void drawRect3D(int x, int y, int wd, int hg, int color,
			int colorLeft, int colorRight) {
		int y2 = y + hg - 1;
		int x2 = x + wd - 1;
		drawLine(x, y, x, y2, colorLeft);
		drawLine(x + 1, y, x2, y, colorLeft);

		drawLine(x2, y + 1, x2, y2 - 1, colorRight);
		drawLine(x + 1, y2, x2, y2, colorRight);

		drawRect(x + 1, y + 1, wd - 1, hg - 1, color);
	}

	public void drawRoundRect(int x, int y, int wd, int hg, int k, int color) {
		int x2 = x + wd - 1;
		int y2 = y + hg - 1;

		drawCircle(x + k + 1, y + k + 1, k, color);
		drawCircle(x + k + 1, y2 - k - 1, k, color);

		drawCircle(x2 - k - 1, y2 - k - 1, k, color);
		drawCircle(x2 - k - 1, y + k + 1, k, color);

		drawRect(x + k, y + 1, wd - k * 2, k - 1, color);
		drawRect(x + 1, y + k, wd - 2, hg - 1 - k * 2, color);
		drawRect(x + k, y2 - k, wd - k * 2, k - 1, color);

	}

	public void drawRoundRect3D(int x, int y, int wd, int hg, int k, int color,
			int colorLeft, int colorRight) {
		int x2 = x + wd - 1;
		int y2 = y + hg - 1;

		drawCircle(x + k, y + k, k, colorLeft);
		drawCircle(x + k, y2 - k, k, colorLeft);
		drawCircle(x + k + 1, y + k + 1, k, color);
		drawCircle(x + k + 1, y2 - k - 1, k, color);

		drawCircle(x2 - k, y2 - k, k, colorRight);
		drawCircle(x2 - k, y + k, k, colorRight);
		drawCircle(x2 - k - 1, y2 - k - 1, k, color);
		drawCircle(x2 - k - 1, y + k + 1, k, color);

		drawLine(x, y + k, x, y2 - k, colorLeft);
		drawLine(x + k, y, x2 - k, y, colorLeft);

		drawLine(x2, y + k, x2, y2 - k, colorRight);
		drawLine(x + k, y2, x2 - k, y2, colorRight);

		drawRect(x + k, y + 1, wd - k * 2, k - 1, color);
		drawRect(x + 1, y + k, wd - 2, hg - 1 - k * 2, color);
		drawRect(x + k, y2 - k, wd - k * 2, k - 1, color);

	}

	public Rect drawText(int x, int y, int h, String text, int piColor,
			Align pAlignX, Align pAlignY) {
		initCanvas();

		Rect bounds = new Rect();
		paint.setTextSize(h);
		paint.getTextBounds(text, 0, text.length(), bounds);
		int hg = bounds.height();
		double f = 1.0 * h / hg;
		if (f != 1) {
			h = (int) (h * f);
			paint.setTextSize(h);
			paint.getTextBounds(text, 0, text.length(), bounds);
			hg = bounds.height();
		}

		int wd = Math.min(bounds.right, image.getWidth());

		if (piColor == Color.BLACK) {
			paint.setColor(Color.WHITE);
		} else {
			paint.setColor(Color.BLACK);
		}
		canvas.drawRect(0, 0, wd, hg, paint);
		paint.setColor(piColor);
		canvas.drawText(text, 0, hg - bounds.bottom, paint);

		int[] pxl = new int[wd * hg];
		image.getPixels(pxl, 0, wd, 0, 0, wd, hg);

		if (pAlignX.equals(Align.CENTER)) {
			x -= wd / 2;
		} else if (pAlignX.equals(Align.RIGHT)) {
			x -= wd;
		}
		if (pAlignY.equals(Align.CENTER)) {
			y -= hg / 2;
		} else if (pAlignY.equals(Align.RIGHT)) {
			y -= hg;
		}
		int off = 0;
		for (int j = 0; j < hg; j++) {
			for (int i = 0; i < wd; i++) {
				int color = pxl[off];
				if (color == piColor) {
					setPixel(x + i, y + j, color);
				}
				off++;
			}
		}
		bounds.set(0, 0, wd, hg);
		return bounds;
	}

	public Bitmap getBimap() {
		image.setPixels(pixels, 0, width, 0, 0, width, height);
		return image;
	}

	public int getHeight() {
		return image.getHeight();
	}

	public int getPixel(int x, int y) {
		return pixels[x + y * width];
	}

	public int getWidth() {
		return image.getWidth();
	}

	private void initCanvas() {
		if (canvas == null) {
			canvas = new Canvas(image);
			paint = new Paint();
		}
	}

	public void random(int gray, double d) {
		int red = Color.red(gray);
		int green = Color.green(gray);
		int blue = Color.blue(gray);
		double e = 1 + d / 2;
		for (int i = 0; i < pixels.length; i++) {
			double r1 = e - Math.random() * d;
			double r2 = e - Math.random() * d;
			double r3 = e - Math.random() * d;
			pixels[i] = Color.argb(255, Math.min(255, (int) (red * r1)),
					Math.min(255, (int) (green * r2)),
					Math.min(255, (int) (blue * r3)));
		}
	}

	public void recycle() {
		image.recycle();
	}

	public void setIconColor(int pColor, int pWhite, int pBlack) {
		int col0 = pixels[0];
		int x = width;
		int x1 = x + 1;
		int x2 = x + width;
		for (int j = 0; j < height - 2; j++) {
			for (int i = 0; i < width; i++) {
				if (pixels[x] == col0) {
					if (pixels[x1] != col0 || pixels[x2] != col0) {
						pixels[x] = pWhite;
						// pixels[x - 1] = pWhite;
						// pixels[x - width] = pWhite;
						// pixels[x - width - 1] = pWhite;
					}
				} else {
					if (pixels[x1] == col0 || pixels[x2] == col0) {
						pixels[x] = pBlack;
						// pixels[x - 1] = pBlack;
						// pixels[x - width] = pBlack;
						// pixels[x - width - 1] = pBlack;
					} else {
						if (pColor != 0) {
							pixels[x] = pColor;
						}
					}
				}
				x++;
				x1++;
				x2++;
			}
		}
	}

	public void setPixel(int x, int y, int color) {
		int i = x + y * width;
		if (i >= 0 && i < pixels.length) {
			pixels[i] = color;
		}
	}
}
